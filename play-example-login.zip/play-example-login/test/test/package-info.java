/**
 * Provides tests.
 */
package test;